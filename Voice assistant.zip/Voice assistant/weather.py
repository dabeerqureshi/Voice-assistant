import requests

# Replace 'your_api_key_here' with your actual API key
api_key = "08c9f420da9766a03126f52852888f31"
city = 'Islamabad'
api_address = f'https://api.openweathermap.org/data/2.5/weather?q={city}&appid={api_key}'
json_data = requests.get(api_address).json()

if "main" in json_data and "weather" in json_data:
    def temp():
        temperature = round(json_data["main"]["temp"] - 273.15, 1)
        return temperature

    def des():
        description = json_data["weather"][0]["description"]
        return description

    print(temp())
    print(des())
else:
    print("Error:", json_data.get("message", "Unexpected error"))
