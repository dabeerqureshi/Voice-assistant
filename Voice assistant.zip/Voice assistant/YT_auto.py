from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

class Music:
    def __init__(self):
        # Path to the chromedriver executable
        path_to_chromedriver = "E:/chromedriver-win64/chromedriver.exe"
        self.driver = webdriver.Chrome(service=Service(path_to_chromedriver))
    
    def play(self, query):
        self.query = query
        self.driver.get("https://www.youtube.com/results?search_query=" + query)
        
        try:
            # Explicit wait for the video element to be clickable
            video = WebDriverWait(self.driver, 20).until(
                EC.element_to_be_clickable((By.XPATH, '//*[@id="video-title"]'))
            )
            video.click()
        except Exception as e:
            print(f"An error occurred: {e}")
        
        # Keep the browser open for a while to observe the result
        time.sleep(60)  # Keep the browser open for 60 seconds

#assist = Music()
#assist.play('dynamite by bts')
