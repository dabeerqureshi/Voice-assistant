from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
import time

class Info:
    def __init__(self):
        # Path to the chromedriver executable
        path_to_chromedriver = "E:/chromedriver-win64/chromedriver.exe"
        self.driver = webdriver.Chrome(service=Service(path_to_chromedriver))

    def get_info(self, query):
        self.query = query
        self.driver.get(url="https://www.wikipedia.org/")
        time.sleep(10)  # Keeps the browser open for 2 seconds
        search = self.driver.find_element(By.XPATH, '//*[@id="searchInput"]')
        search.click()
        search.send_keys(query)
        enter = self.driver.find_element(By.XPATH, '//*[@id="search-form"]/fieldset/button')
        enter.click()

# Instantiate and call the method
#assist = Info()
#assist.get_info("Artificial Intelligence")
