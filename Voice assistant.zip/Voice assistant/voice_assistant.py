import pyttsx3 as p
import speech_recognition as sr
from selenium_web import Info
from YT_auto import Music
from News import news
import randfacts
from jokes import *


# Basic Settings
engine = p.init()
engine.setProperty('rate', 130)
voices = engine.getProperty('voices')
engine.setProperty('voice', voices[1].id)

def speak(text):
    engine.say(text)
    engine.runAndWait()

# Converting voice to text
r = sr.Recognizer()

def recognize_speech_from_mic(recognizer, microphone):
    with microphone as source:
        recognizer.adjust_for_ambient_noise(source, duration=1.2)
        print("Listening...")
        audio = recognizer.listen(source)
    response = ""
    try:
        response = recognizer.recognize_google(audio)
        print("You said: {}".format(response))
    except sr.RequestError:
        speak("API unavailable")
    except sr.UnknownValueError:
        speak("Sorry, I did not catch that")
    return response

speak('Hello sir, I am your voice assistant. How are you?')

mic = sr.Microphone()

text = recognize_speech_from_mic(r, mic)

if "what" in text and "about" in text and "you" in text:
    speak('I am also having a good day sir')
speak('What can I do for you?')

text2 = recognize_speech_from_mic(r, mic)

# Feature 1
if "information" in text2:
    speak("You need information related to which topic?")
    infor = recognize_speech_from_mic(r, mic)
    speak(f"Searching {infor} in Wikipedia")
    print(f"Searching {infor} in Wikipedia")
    assist = Info()
    assist.get_info(infor)
# Feature 2
elif "play" in text2 and "video" in text2:
    speak("You want me to play which video?")
    vid = recognize_speech_from_mic(r, mic)
    speak(f"Playing {vid} on YouTube")
    print(f"Playing {vid} on YouTube")
    assist = Music()
    assist.play(vid)
# Feature 3
elif "news" in text2:
    print("Fetching the latest news")
    speak("Fetching the latest news")
    arr = news()
    for i in range(len(arr)):
        print(arr[i])
        speak(arr[i])
# Feature 4
elif "fact" in text2 or "facts" in text2:
    speak("Sure Sir,")
    x = randfacts.getFact()
    print(x)
    speak("Did you know that, " + x)
# Feature 5
elif "joke" in text2 or "jokes" in text2:
    speak("Sure Sir, get ready for some chuckles")
    ar = joke()
    print(ar[0])
    speak(ar[0])
    print(ar[1])
    speak(ar[1])
